var global = [];

var canada = _.findWhere(exportsToCanada, {'id':'Value 2013'});
canada.id = 'Canada';
global.push(canada);

var Mexico = _.findWhere(exportsToMexico, {'id':'Value 2013'});
Mexico.id = 'Mexico';
global.push(Mexico);

var china = _.findWhere(exportsToChina, {'id':'Value 2013'});
china.id = 'China';
global.push(china);

var Japan = _.findWhere(exportsToJapan, {'id':'Value 2013'});
Japan.id = 'Japan';
global.push(Japan);

var France = _.findWhere(exportsToFrance, {'id':'Value 2013'});
France.id = 'France';
global.push(France);

var SaudiArabia = _.findWhere(exportsToSaudiArabia, {'id':'Value 2013'});
SaudiArabia.id = 'SaudiArabia';
global.push(SaudiArabia);

var israel = _.findWhere(exportsToIsrael, {'id':'Value 2013'});
israel.id = 'Israel';
global.push(israel);

var Argentina = _.findWhere(exportsToArgentina, {'id':'Value 2013'});
Argentina.id = 'Argentina';
global.push(Argentina);

var Iraq = _.findWhere(exportsToIraq, {'id':'Value 2013'});
Iraq.id = 'Iraq';
global.push(Iraq);

var Pakistan = _.findWhere(exportsToPakistan, {'id':'Value 2013'});
Pakistan.id = 'Pakistan';
global.push(Pakistan);

var haiti = _.findWhere(exportsToHaiti, {'id':'Value 2013'});
haiti.id = 'Haiti';
global.push(haiti);

var cuba = _.findWhere(exportsToCuba, {'id':'Value 2013'});
cuba.id = 'Cuba';
global.push(cuba);

var SierraLeone = _.findWhere(exportsToSierraLeone, {'id':'Value 2013'});
SierraLeone.id = 'SierraLeone';
global.push(SierraLeone);

var VaticanCity = _.findWhere(exportsToVaticanCity, {'id':'Value 2013'});
VaticanCity.id = 'VaticanCity';
global.push(VaticanCity);

